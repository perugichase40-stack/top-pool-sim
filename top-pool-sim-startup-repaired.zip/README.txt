TOP POOL SIM - STARTUP REPAIR

1. Extract ALL files into a new folder.
2. Double-click START-GAME.bat.
3. The launcher downloads Three.js into this folder the first time, then starts a local web server.
4. Keep the server window open while playing.

The game now imports Three.js from a local file instead of asking the browser to import it directly from the CDN each time. An internet connection is required for the first library download. If the download fails, the launcher will show an error rather than opening a broken game.

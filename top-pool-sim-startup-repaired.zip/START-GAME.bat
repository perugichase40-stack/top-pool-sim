@echo off
setlocal
cd /d "%~dp0"
title Top Pool Sim - Local Game Server

if not exist "three.module.js" (
  echo Downloading the 3D graphics library for the game...
  powershell -NoProfile -ExecutionPolicy Bypass -Command "try { Invoke-WebRequest -UseBasicParsing 'https://cdn.jsdelivr.net/npm/three@0.160.0/build/three.module.js' -OutFile 'three.module.js'; if ((Get-Item 'three.module.js').Length -lt 1000000) { throw 'Downloaded library looks incomplete.' } } catch { Write-Host 'Could not download the 3D library.' -ForegroundColor Red; Write-Host $_.Exception.Message; exit 1 }"
  if errorlevel 1 (
    echo.
    echo The library download failed. Check your internet connection and try again.
    pause
    exit /b 1
  )
)

where py >nul 2>nul
if %errorlevel%==0 (
  start "Top Pool Sim server" /min cmd /c "py -m http.server 8000"
) else (
  where python >nul 2>nul
  if %errorlevel%==0 (
    start "Top Pool Sim server" /min cmd /c "python -m http.server 8000"
  ) else (
    echo Python was not found. Install Python, then run this file again.
    pause
    exit /b 1
  )
)
timeout /t 2 /nobreak >nul
start "" http://localhost:8000/index.html
endlocal
